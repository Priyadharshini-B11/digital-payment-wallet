document.getElementById('signupForm').addEventListener('submit', function (e) {
    e.preventDefault();

    // Get the email and password input values
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    // Save to local storage (in real scenarios, store password securely)
    localStorage.setItem('email', email);
    localStorage.setItem('password', password);

    alert('Account created successfully! Please log in.');
    window.location.href = 'login.html'; // Redirect to login page
});
