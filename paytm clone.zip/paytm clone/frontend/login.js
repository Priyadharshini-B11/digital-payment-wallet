document.getElementById('loginForm').addEventListener('submit', function (e) {
    e.preventDefault();

    // Get the email and password input values
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    // Validate login credentials (this is just an example, modify as needed)
    const storedEmail = localStorage.getItem('email');
    const storedPassword = localStorage.getItem('password'); // Ensure you have a way to store password securely

    if (email === storedEmail && password === storedPassword) {
        // Successful login
        localStorage.setItem('loggedIn', true); // Track logged-in status
        window.location.href = 'index.html'; // Redirect to main page (or dashboard)
    } else {
        // Show error message
        alert('Invalid email or password');
    }
});
