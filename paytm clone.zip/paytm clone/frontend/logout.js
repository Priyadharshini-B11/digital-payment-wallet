function logout() {
    // Clear user session data from localStorage
    localStorage.removeItem('userProfile');
    localStorage.removeItem('loggedIn');
    
    // Redirect user to login page
    window.location.href = 'login.html';
}
