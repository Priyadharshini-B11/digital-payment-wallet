let cardNumInput = document.querySelector('#cardNum');

cardNumInput.addEventListener('keyup', () => {
    let cNumber = cardNumInput.value;
    cNumber = cNumber.replace(/\s/g, "");

    if (Number(cNumber)) {
        cNumber = cNumber.match(/.{1,4}/g);
        cNumber = cNumber.join(" ");
        cardNumInput.value = cNumber;
    }
});

document.querySelector('form').addEventListener('submit', (event) => {
    event.preventDefault(); // Prevent default form submission

    // Perform any validation if required
    const cardNumInput = document.querySelector('#cardNum').value;
    if (cardNumInput.length < 19) {
        alert('Please enter a valid card number.');
        return;
    }

    // Navigate to the next page
    window.location.href = 'nextpage.html';
});