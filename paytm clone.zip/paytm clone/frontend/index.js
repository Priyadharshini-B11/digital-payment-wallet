document.getElementById('paymentForm').addEventListener('submit', function (e) {
    e.preventDefault();

    const email = document.getElementById('email').value;
    const billingAddress = document.getElementById('address').value;
    const cardNum = document.getElementById('cardNum').value;
    const coupon = document.getElementById('coupon').value;

    // Calculate discount
    let discount = 0;
    if (coupon === 'SAVE10') discount = 10;

    const lastFour = cardNum.slice(-4);
    const amount = 100; // Example amount
    const finalAmount = amount - discount;

    localStorage.setItem('email', email);
    localStorage.setItem('billingAddress', billingAddress);
    localStorage.setItem('cardLastFour', lastFour);
    localStorage.setItem('discount', discount);

    // Save to transaction history
    const history = JSON.parse(localStorage.getItem('transactionHistory')) || [];
    history.push({
        orderId: Math.floor(Math.random() * 1000000),
        date: new Date().toLocaleString(),
        amount: finalAmount,
    });
    localStorage.setItem('transactionHistory', JSON.stringify(history));

    window.location.href = 'nextpage.html';
});

function viewHistory() {
    window.location.href = 'history.html';
}

// Add this to handle adding funds (already added to the script tag in the HTML)
function addFunds() {
    const amount = prompt("Enter amount to add to wallet:");
    if (amount && !isNaN(amount) && amount > 0) {
        let currentBalance = parseFloat(localStorage.getItem('walletBalance') || 0);
        currentBalance += parseFloat(amount);
        localStorage.setItem('walletBalance', currentBalance);
        document.getElementById('balance-amount').textContent = currentBalance.toFixed(2);
    } else {
        alert("Invalid amount entered!");
    }
}

