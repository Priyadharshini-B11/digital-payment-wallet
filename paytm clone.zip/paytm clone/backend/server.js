// Importing required packages
const express = require('express');
const mongoose = require('mongoose');
const dotenv = require('dotenv'); // For loading environment variables

// Load environment variables
dotenv.config();

// Create an Express app
const app = express();

// MongoDB connection
mongoose.connect('mongodb://127.0.0.1:27017/ecommerce', {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
  .then(() => {
    console.log('MongoDB connected!');
  })
  .catch((err) => {
    console.error('MongoDB connection error:', err);
  });

// Middlewares
app.use(express.json()); // Middleware to parse JSON requests

// Routes (for example, product routes)
app.get('/api/products', (req, res) => {
  res.json([]);
});

// Server
app.listen(5000, () => {
  console.log('Server running on port 5000');
});